complete -W '--help' dwim
