grep --color=always "pattern" ./*middle*
