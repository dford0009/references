warn() {
    printf "%s\n" "$@" >&2
}
