script_directory="$(dirname "${BASH_SOURCE[0]}")"

echo "I'm in ${script_directory}"
