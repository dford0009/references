#!/usr/bin/env bash

set -o errexit

false

destroy-all-humans
